package KEYWORD_WITH_TC_SEL;
public class tc {

	
	public String tcid;
	public String flag;
	public int no_steps;
	public String test_data_sh;
}
