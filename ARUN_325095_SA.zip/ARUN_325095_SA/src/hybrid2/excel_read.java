package hybrid2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import hybrid.login_test_data;

public class excel_read {
public static String  filename="Book1.xlsx";
public static String kw_sheet="sheet7";
public static String tc_sheet="TC_SELECTION_SH";
public static XSSFSheet kw_sh_obj,tc_sh_obj,td_sh_obj;
public static ArrayList<login_test_data> td_al;


	public static   XSSFSheet set_sheet(String s) {
	//	System.out.println("in set sheet");
		XSSFSheet sh1 = null;
		
		//System.out.println(s);
	
		try {
			File f=new File(filename);
			FileInputStream 	fis = new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			sh1=wb.getSheet(s);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return sh1;
		
	}
	
	public static keyword_sh read_kw_sh(int i) {
		keyword_sh kw=new keyword_sh();
		kw_sh_obj=set_sheet(kw_sheet);
		XSSFRow rw=kw_sh_obj.getRow(i);
		kw.TC_ID=rw.getCell(0).getStringCellValue();
		kw.step_no=rw.getCell(1).getStringCellValue();
		kw.KeyWord=rw.getCell(3).getStringCellValue();
		kw.Xpath=rw.getCell(3).getStringCellValue();
		kw.Test_data=rw.getCell(4).getStringCellValue();
		return kw;
		
	}
	
	public static void get_test_data(String shname,int row,int col) {
		td_sh_obj=set_sheet(shname);
		login_test_data td;
		td_al=new ArrayList<login_test_data>();
		int r,c;
		for(r=1;r<=row;r++) {
			td=new login_test_data();
			td.uid=td_sh_obj.getRow(r).getCell(0).getStringCellValue();
			td.pwd=td_sh_obj.getRow(r).getCell(1).getStringCellValue();
		
			System.out.println("test data:"+td.uid+","+td.pwd);
			td_al.add(td);
		}
	}
}
