package hybrid2;


import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class HFW extends excel_read {
 
	public  void read_exc() {
		//System.out.println("in read");
		XSSFSheet sh=set_sheet("sheet9");
	
		int r=sh.getLastRowNum();
		for(int i=1;i<=r;i++) {
			XSSFRow r1=sh.getRow(i);
			XSSFCell c=r1.getCell(0);
			String s=c.getStringCellValue();
			XSSFCell c1=r1.getCell(1);
			
			String s1=c1.getStringCellValue();
			
			
			if(s1.equals("Y")) {
				
			
		
			System.out.println(s+":"+s1);
			
		}
	}
		
		
		
		for(int i=1;i<18;i++) {
			System.out.println( read_kw_sh(i).KeyWord);
			 
			
		}
		
		
		get_test_data("sheet8",2,2);
	}
	public static void main(String[] args) {
		HFW re=new HFW();
		re.read_exc();

	}

}
