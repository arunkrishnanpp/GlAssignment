package SDAY3;

public class login {
String uid,pass,ex_r,ac_r,test_r;
}
