package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test2  {

	WebDriver dr;

	String xname="//*[@id=\"Email\"]";
	String xpass="//*[@id=\"Password\"]";
	String xsubmit="/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input";
	

	@When("^User invaluid login data and click ok button$")
	public void user_invaluid_login_data_and_click_ok_button() throws Throwable {
	  System.out.println("User invaluid login data and click ok button");
	  dr=test1.dr;
	  dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("buefnhomber@gmail.com");
		dr.findElement(By.xpath(xpass)).sendKeys("arunpp65@gmail.com");
		dr.findElement(By.xpath(xsubmit)).click();
	}

	@Then("^error mesgae displyed$")
	
	public void error_mesgae_displyed() throws Throwable {
	System.out.println("error mesgae displyed");   
	
	
	
	String s1="Login was unsuccessful. Please correct the errors annd try again.";
	String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
	

	SoftAssert as=new SoftAssert();
	as.assertEquals(s, s1);
	as.assertAll();
	}

	
	
	
	
	
}
