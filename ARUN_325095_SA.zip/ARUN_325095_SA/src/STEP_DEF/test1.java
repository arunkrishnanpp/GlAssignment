package STEP_DEF;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/*public class test1 {

	WebDriver dr;
	
	String xname="//input[@placeholder='Username']";
	String xpass="//input[@placeholder='Password']";
	String xsubmit="//*[@id=\"login_button_container\"]/div/form/input[3]";
	
	@Given("^Login page is displayed$")
	public void login_page_is_displayed() throws Throwable {
	
		
		System.out.println("Login page is displayed");  

		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		dr=new ChromeDriver();
		dr.get("http://www.saucedemo.com/");
	}
	

	@When("^User enters login data and click ok button$")
	public void user_enters_login_data_and_click_ok_button() throws Throwable {
	   System.out.println("User enters login data and click ok button");
		dr.findElement(By.xpath(xname)).sendKeys("standard_user");
		dr.findElement(By.xpath(xpass)).sendKeys("secret_sauce");
		dr.findElement(By.xpath(xsubmit)).click();
		
	}

	@Then("^Home page is displayed$")
	public void home_page_is_displayed() throws Throwable {
	  System.out.println("home page displyed");
	  
	  
	  
	  dr.findElement(By.xpath("//*[@id=\"menu_button_container\"]/div/div[3]/div/button")).click();
		String s1="Logout";
		Thread.sleep(20);
	  String s= dr.findElement(By.xpath("//*[@id=\"logout_sidebar_link\"]")).getText();
	  dr.findElement(By.xpath("//*[@id=\"logout_sidebar_link\"]")).click();

	System.out.println(s);
	
	
	
	
	
	SoftAssert as=new SoftAssert();
	as.assertEquals(s, s1);
	as.assertAll();
	
	
	}

	
	
	
	
	
	
	
}

*/












public class test1 {

	static WebDriver dr;

	String xname="//*[@id=\"Email\"]";
	String xpass="//*[@id=\"Password\"]";
	String xsubmit="/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input";
	
	@Given("^Login page is displayed$")
	public void login_page_is_displayed() throws Throwable {
	
		
		System.out.println("Login page is displayed");  

		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		//test2 t1=new test2(dr);
	}
	



	@When("^User enters login data and click ok button$")
	public void user_enters_login_data_and_click_ok_button() throws Throwable {
	   System.out.println("User enters login data and click ok button");
		dr.findElement(By.xpath(xname)).sendKeys("buenhomber@gmail.com");
		dr.findElement(By.xpath(xpass)).sendKeys("arunpp65@gmail.com");
		dr.findElement(By.xpath(xsubmit)).click();
		
	}

	@Then("^Home page is displayed$")
	public void home_page_is_displayed() throws Throwable {
	  System.out.println("home page displyed");
	  
	  
	  
	 
		Thread.sleep(20);
		String s1="Log out";
	  String s= dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).getText();
	 // dr.findElement(By.xpath("//*[@id=\"logout_sidebar_link\"]")).click();

	System.out.println(s);
	
	
	
	
	
	SoftAssert as=new SoftAssert();
	as.assertEquals(s, s1);
	
	as.assertAll();
	
	
	}

	
	
	
	
	
	
	
}
