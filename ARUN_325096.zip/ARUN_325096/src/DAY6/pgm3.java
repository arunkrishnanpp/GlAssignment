package DAY6;

import java.util.ArrayList;



public class pgm3 {
	ArrayList<Student> std_li=new ArrayList<Student>();
	
public void Create() {
	
	Student s1=new Student(16,"cr",43,77);
	Student s2=new Student(16,"messi",50,50);
	
	std_li.add(s1);
	std_li.add(s2);
	
	
	
	
	
	
}
public void dispay() {

	for(Student s:std_li) {
		s.avg();
	System.out.println(" rollno:"+s.rollno+" name:"+s.name+" mark1:"+s.m1+" mark2:"+s.m2+" average:"+s.avg);
	}}
	public static void main(String[] args) {
		pgm3 a=new pgm3();
		a.Create();
		a.dispay();
		// TODO Auto-generated method stub

	}

}
