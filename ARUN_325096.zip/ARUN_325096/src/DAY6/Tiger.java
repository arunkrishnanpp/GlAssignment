package DAY6;

public class Tiger extends Animal{
	int leghtofteath;
	int lenghtofclaw;
	public void iam() {
		System.out.println("******************\ni am tiger");
	}
	public void roar() {
		System.out.println("Tiger Roars");
	}
	

	public void climb() {
		System.out.println("Tiger climbs tree");
	}
	
	public void mauls() {
		System.out.println("Tiger mauls its prey");
	}
	
		
		
	public Tiger(int lott, int loc, int i, String string, String string2, String string3, String string4) {
		// TODO Auto-generated constructor stub
		this.leghtofteath=lott;
		this.lenghtofclaw=loc;

		this.age=i;
		this.color=string;
		this.food=string2;
		this.gender=string3;
	this.name=string4;
	
	
	
	
	iam();
	display();
	display_tiger();

	climb();
	eats();
	mauls();
	roar();
	runs();
	
	}


	public void display_tiger() {
		
		
		System.out.println("\n Length of teeth : "+ this.leghtofteath + "\n Length of claws : " + this.lenghtofclaw);
	}

}
