package DAY6;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String []arry= {"hii","hello"};
		
		
		for(String s: arry)
			System.out.println(s);
	}

}
