package WEEKEND_ASSIGNEMNT2;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	int[] array= {23,44,84,37,91,18};
	
	int sum=0;
	for(int i=2;i<array.length;i=i+2) {
		if(array[i]%2!=0) {
			sum+=array[i];
		}
	}
	
	
	System.out.println(""
			+ "SUM OF ODD NUMBER IN EVEN POSITION = "+sum);
		
		
	}

}
