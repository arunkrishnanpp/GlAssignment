package WEEKEND_ASSIGNEMNT2;

public class Product {
	
	
	
	int product_id;
	String poduct_name;
	float unit_price;
	int unit_purchase;
	float price;
	String product_grade;
	public void Price() {
		// TODO Auto-generated method stub
		this.price=this.unit_price*this.unit_purchase;
	}
	public void Product_Grade() {
		
		if(this.price<25000)
			this.product_grade="Grade A";
		if(this.price>=25000)
			this.product_grade="Grade B";
		// TODO Auto-generated method stub
		
	}
	
	
	
	
	

}
