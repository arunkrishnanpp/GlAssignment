package WEEKEND_ASSIGNEMNT2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class exel_operation extends pgm7 {
	
	public void read_excel() {
//ArrayList<Product>li=new ArrayList<Product>();
		list=new ArrayList<Product>();
		
		for(int i=1;i<4;i++) {
			Product p=new Product();
			
		
		try {
			File f=new File("C:\\Gltraining\\product.xlsx");
			FileInputStream fi=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fi);
			XSSFSheet sh=wb.getSheet("sheet1");
			XSSFRow r=sh.getRow(i);
			XSSFCell c=r.getCell(0);
			p.product_id=(int) c.getNumericCellValue();
			
			XSSFCell c1=r.getCell(1);
			p.poduct_name=c1.getStringCellValue();
			XSSFCell c2=r.getCell(2);
			p.unit_price=(float) c2.getNumericCellValue();
			XSSFCell c3=r.getCell(3);
			p.unit_purchase=(int) c3.getNumericCellValue();
		
			list.add(p);
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
 catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}

	public void write_excel() {
		// TODO Auto-generated method stub
		int m=1;
		
		
		
		try {
			File f=new File("C:\\Gltraining\\product.xlsx");
			FileInputStream fi1=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fi1);
			XSSFSheet sh=wb.getSheet("sheet1");
			for(Product p:list) {
			
			XSSFRow r=sh.getRow(m);
			XSSFCell c=r.createCell(4);
			c.setCellValue(p.price);
			XSSFCell c1=r.createCell(5);
			c1.setCellValue(p.product_grade);
			FileOutputStream fo=new FileOutputStream(f);
			wb.write(fo);
			m++;
			
			
			
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}
		
	}

	
	
	
	

