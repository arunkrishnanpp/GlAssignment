package WEEKEND_ASSIGNEMNT2;

import java.util.ArrayList;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<student>list=new ArrayList<student>();
student s1=new student(7,"CR",98,55);
student s2=new student(10,"MESSI",66,88);
student s3=new student(11,"NEYMAR",20,44);
list.add(s1);
list.add(s2);

list.add(s3);


for(student x:list) {
if(x.avg>65) {
	System.out.println("STUDENT DETAILS");
	System.out.println("ROLL NO:"+x.rollno);
	System.out.println("NAME:"+x.name);
	System.out.println("JAVA MARK:"+x.java);
	System.out.println("SELENIUM MARK:"+x.selnium);
	System.out.println("AVERAGE MARK:"+x.avg);
	
	System.out.println("*************************************");
	
}
	
	
}


}
	
}
