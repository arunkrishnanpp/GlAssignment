package WEEKEND_ASSIGNEMNT2;



public class student {
	int rollno;
	String name;
	float java;
	float selnium;
	float avg;
	public student(int rollno, String name, float java, float selnium) {
		
		this.rollno = rollno;
		this.name = name;
		this.java = java;
		this.selnium = selnium;
		average();
	}
	
	
	public void average() {
		this.avg=(this.java+this.selnium)/2;
	}
	
}