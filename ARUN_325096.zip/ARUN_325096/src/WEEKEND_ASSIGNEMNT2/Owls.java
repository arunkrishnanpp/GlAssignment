package WEEKEND_ASSIGNEMNT2;

public class Owls extends Bird{

	
	public void iam() {
		System.out.println("******************\ni am Owl");
	}
	

	public void fly() {
		System.out.println("owls fly scilently");
	}
	
	public void camouflage() {
		System.out.println("owls are master of camouflage");
	}
	
	public Owls(
			int no_of_leg,
			String color,
			String food,
			String name,
			String gender,
			int age,
			String species,
			String region,
			String climate) {
		
		this.no_of_leg=no_of_leg;
		this.color=color;
		 this.food=food;
		this.name=name;
		this.gender=gender;
		this.age=age;
		
		 this.species=species;
	 this.region=region;
		 this.climate=climate;
		
		 iam();
		 make_sound();
		 fly();
		 camouflage();
		
		 
		 display();
		
		
		
	}


	private void make_sound() {
		System.out.println("owl makes sound");
		// TODO Auto-generated method stub
		
	}
		



	
}
