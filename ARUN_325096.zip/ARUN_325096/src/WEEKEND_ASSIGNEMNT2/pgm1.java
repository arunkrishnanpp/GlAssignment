package WEEKEND_ASSIGNEMNT2;

import java.util.ArrayList;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				
		ArrayList<Integer>list =new ArrayList<Integer>();
		
		for(int i=10;i<=30;i++) {
			if(i%2==0)
				list.add(i);
		}
		
		for(Integer X:list)
			System.out.println(X
					);
		
		
		
	}

}
