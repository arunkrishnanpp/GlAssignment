package DAY1;

public class pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
char ch='a';

if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
	System.out.println(ch+"is vowel");
else
	System.out.println(ch+"not vowel");




char ch1='z';

if(ch1=='a'||ch1=='e'||ch1=='i'||ch1=='o'||ch1=='u'||ch1=='A'||ch1=='E'||ch1=='I'||ch1=='O'||ch1=='U')
	System.out.println(ch1+"is vowel");
else
	System.out.println(ch1+"not vowel");

	}

}
