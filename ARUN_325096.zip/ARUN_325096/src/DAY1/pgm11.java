package DAY1;

public class pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=12;
		int c=33;
		
		
		if(a>b)
		{
			if(a>c)
				System.out.println("a is grater");
			else
				System.out.println("c is grater");
			
		}
		else if(b>a)
		
		{
			if(b>c)
				System.out.println("b is grater");
			else
				System.out.println("c is grater");
		}
		else 
			System.out.println("c is grater");
	}

}
