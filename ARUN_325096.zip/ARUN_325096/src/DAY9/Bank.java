package DAY9;

public class Bank {

	
	
	public float ROI() {
		return 0f;
	}
	
	
}
