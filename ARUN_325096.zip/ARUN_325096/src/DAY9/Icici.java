package DAY9;

public class Icici extends Bank {
	
	
	
	public float ROI() {
		return 4.7f;
	}

}
