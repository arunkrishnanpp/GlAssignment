package DAY9;

public class driver_bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Bank b;
		
		
		b=new Icici();
		System.out.println("ICICI"+b.ROI());
		
		
		
		b=new hdfc();
		System.out.println("HDFC"+b.ROI());
		
		
	}

}
