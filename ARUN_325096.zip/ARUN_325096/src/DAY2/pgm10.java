package DAY2;

public class pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 0,b=10,c=15;
		a=add(b,c);
		System.out.println("sum of "+b+"and "+c+"is"+a);
	}

	public static  int add(int x, int y) {
		// TODO Auto-generated method stub
		
		int v=x+y;
		return v;
	}

}
