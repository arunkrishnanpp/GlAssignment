package DAY2;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int s=2;
switch(s) {
case 2:System.out.println("two");
case 5:System.out.println("two");break;
case 9:System.out.println("two");
default:System.out.println("no match");

};
System.out.println("out of switch");
	}

}

