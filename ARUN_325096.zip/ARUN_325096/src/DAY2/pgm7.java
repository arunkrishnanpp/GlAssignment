package DAY2;

public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//in s given number  calculate sum all digit that are grater than 5
	int num =59158;
	int sum=0,d;
	while(num>0) {
		d=num%10;
		if(d>5)
			sum+=d;
		num/=10;
	}
	
	
	System.out.println(sum);
	
	System.out.println(5/10);
	
	}

}
