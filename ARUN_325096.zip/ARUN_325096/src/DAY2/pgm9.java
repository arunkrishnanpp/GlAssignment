package DAY2;

public class pgm9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=5,b=4;
for(int i=0;i<5;i++) {
	
	
	System.out.println("a*b="+a*b);
	a++;
	b+=2;
}
	}

}
