package DAY4;

public class calc {

public void add(int x,double d) {
	System.out.println(x+d);
}
public float add(float x,float y) {
	return (x+y);
}

public void add(int x,float y) {
	System.out.println(x+y);
}


}
