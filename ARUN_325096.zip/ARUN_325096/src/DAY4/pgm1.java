package DAY4;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int cmax=4;
		int dmax=1;
		//int xmax=1;
		for(int r=1;r<=3;r++) {
			
			
			
			for(int c=1;c<=cmax;c++) {
				System.out.print(" ");
				
			}
			for(int d=1;d<=dmax;d++) {
				System.out.print(1+" ");
			
			
				
				
			}
			
			
			
			cmax-=2;
			dmax++;
			System.out.println();
			for(int k=1;k<=r;k++)
			{
				System.out.print(" ");
			}
//			
			
		}
		
		
		
		
	}

}
