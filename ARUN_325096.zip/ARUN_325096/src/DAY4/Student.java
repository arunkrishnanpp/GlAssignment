package DAY4;

public class Student {

	
	int rollno;
	String name;
	int m1;
	float avg;
	 Student(int rollno,String name,int m1) {
			this.rollno=rollno;
			this.name=name;
			this.m1=m1;
	 }
			
			public void display() {
				System.out.println("name="+this.name);
				System.out.println("roll no="+this.rollno);
				System.out.println("mark="+this.m1);
			}
			
			public static void main(String[] args) {
				// TODO Auto-generated method stub
				
				
				Student s1=new Student(10,"rakesh",66);
				s1.display();
				
				//System.out.println(s1.m1);
			}
		
		
	

}
