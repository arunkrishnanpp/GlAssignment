package DAY8;

import java.util.ArrayList;

public class mainnnn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Exl_operation op=new Exl_operation();
		//Passenger m=new Passenger();
		ArrayList<Passenger> out=new ArrayList<Passenger>();
		
		
		out=op.read_exl();
		
		for(Passenger m:out)
			System.out.println(m.t);
		
		//op.write_exl(m);
		op.write_exl(out);
		
		
		

	}

}
