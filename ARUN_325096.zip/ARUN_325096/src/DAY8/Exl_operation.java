package DAY8;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Exl_operation {
	int m=1;
	ArrayList<Passenger> pas=new ArrayList<Passenger>();
	public ArrayList<Passenger> read_exl(){
		for(int i=1;i<=m;i++) {
		
			Passenger p=new Passenger();
			
			
			
			try {
				File f=new File("C:\\Gltraining\\pss.xlsx");
				FileInputStream fi=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fi);
				XSSFSheet sh=wb.getSheet("sheet1");
				int fir=sh.getFirstRowNum();
				int ls=sh.getLastRowNum();
				m=ls-fir;
				XSSFRow r=sh.getRow(i);
				XSSFCell c=r.getCell(0);
				p.sl_no=(int) c.getNumericCellValue();
				XSSFCell c1=r.getCell(1);
				p.name=c1.getStringCellValue();
				XSSFCell c2=r.getCell(2);
				p.from=c2.getStringCellValue();
				
				XSSFCell c3=r.getCell(3);
				p.to=c3.getStringCellValue();
				
				
				XSSFCell c4=r.getCell(4);
				p.rate=c4.getNumericCellValue();
				
				XSSFCell c5=r.getCell(5);
				p.no_seat=(int) c5.getNumericCellValue();
				
				
				
				p.total();
				//System.out.println(p.t);
				
				pas.add(p);
				
				
				
				
				
				
				
				
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		}
			
	return pas;	
	}
		
	
	

	public void write_exl(ArrayList<Passenger> out) {
		// TODO Auto-generated method stub
		
		try {
			int m=1;
			
			
			
			
			File f=new File("C:\\Gltraining\\pss.xlsx");
			FileInputStream fi=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fi);
			XSSFSheet sh=wb.getSheet("sheet1");
			
			
			for(Passenger b:out) {
				XSSFRow r=sh.getRow(m);
				XSSFCell c=r.createCell(6);
			c.setCellValue(b.t);
			FileOutputStream fo=new FileOutputStream(f);
			wb.write(fo);
			m++;
			
			
			
			
			
			
			}
			
			
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	}
		
		
		
		
		
	}
	
	
	
	

