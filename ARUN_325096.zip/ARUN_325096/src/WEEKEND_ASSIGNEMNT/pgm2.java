package WEEKEND_ASSIGNEMNT;

public class pgm2 {


	public static void main(String[] args) {
		String str="hello i am working at global logic";
		// TODO Auto-generated method stub

		String [] arry=new String[10];
		//System.out.println(str.length());
		
		arry=extract_word(str);
		
		
	/*	for(int i=0;i<arry.length;i++) {
			System.out.println(arry[i]);
		}*/
		
		
		count_print(arry);
		
		
		
	}

	private static void count_print(String[] arry) {
		// TODO Auto-generated method stub
		for(int i=0;arry[i]!=null;i++) {
			
		
			if(arry[i].length()>5)
				System.out.println(arry[i]);
			
			
		
		}
	}

	private static String[] extract_word(String s1) {
		// TODO Auto-generated method stub
		int p=0,c=0,i=0;
		String []a=new String[20];
		while(p!=-1)
													
		{	
			p=s1.indexOf(" ", p);
			
			
			if(p==-1) {
				//System.out.println(s1.substring(c,s1.length()));
				a[i]=s1.substring(c,s1.length());
				i++;
				break;
			}
			else {
				//System.out.println(s1.substring(c,p));
				a[i]=s1.substring(c,p);
				i++;
			}
			c=p+1;
			p++;
	}

return a;
	
	}
	
	
	
}
