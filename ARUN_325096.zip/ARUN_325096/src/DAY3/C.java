package DAY3;

public class C {
public static void main(String args[]) {
	

	B b1=new B();
	b1.xyz=10;
	b1.abc=29;
	b1.show();
	b1.show2();
}
}