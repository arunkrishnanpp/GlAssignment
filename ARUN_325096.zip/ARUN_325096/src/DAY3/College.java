package DAY3;

public class College {

	public static void main(String[] args) {
		
		
		
		
		Student rakesh =new Student();
		Student priya =new Student();
		rakesh.rollno=73;
		rakesh.name="rakesh";
		rakesh.m1=83;
		rakesh.m2=91;
		priya.rollno=12;
		priya.name="priya";
		priya.m1=61;
		priya.m2=44;
		
		rakesh.avg();
		System.out.println("average mark of "+rakesh.name+"  is  "+rakesh.avg);
		priya.avg();
		System.out.println("average mark of "+priya.name+" is "+priya.avg);
		
		
		if(rakesh.avg>priya.avg)
			System.out.println("grater mark for rakesh ");
		else
			System.out.println("grater mark for priya ");
		
		
		//System.out.println(rakesh.rollno);
		// TODO Auto-generated method stub

	}

}
