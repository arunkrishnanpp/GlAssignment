package DAY3;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int marks[][]= {{77,95,83,21,43},{65,92,79,33,66},{44,77,33,63,54,44}};
		
		int m=1;
		int rows[]= {0,0,0,0,0};
		for(int i=0;i<=2;i++) { 
			
			for(int j=0;j<=4;j++) {
				System.out.print(marks[i][j]+" ");
				
				}
				
				
			
			System.out.println();
		}
		
		for(int i=0;i<=2;i++) {
			int c=0;
			for(int j=0;j<=4;j++)
			{
				rows[c]=marks[i][j];
				c++;
				
			}
			max(rows,m);
			m++;
		}
		
		
		
		
	}

	private static void max(int[] rows, int m) {
		// TODO Auto-generated method stub
		
		int l=rows[0];
		for(int i=0;i<=4;i++) {
			if(rows[i]>l) {
				l=rows[i];
			}
		}
		System.out.println("Row"+m+":"+l);
	}
}

