package DAY3;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//find and print two number sum is equal to 65
		
		
		
		
		
		int [] a= {21,34,91,59,16,44,29,36,49,31};
		for(int i=0;i<=9;i++) {
			for(int j=i+1;j<=9;j++) {
				int x=a[i]+a[j];
				if(x==65)
					System.out.println("sum of "+a[i]+"&"+a[j]+"="+x);
			}
		}
	}

}
