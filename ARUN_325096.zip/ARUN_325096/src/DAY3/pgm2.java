package DAY3;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number[]= {21,34,91,59,16,25,29,74,49,82};
		int sum=0;
		
		for(int i=0;i<=9;i++)
		{
			
			if(iseven(number[i])) {
				sum+=number[i];
			}
		}
	
	System.out.println(sum);
	}

	private static boolean iseven(int i) {
		// TODO Auto-generated method stub
		
		if(i%2==0)
			return true;
		return false;
	}

}
