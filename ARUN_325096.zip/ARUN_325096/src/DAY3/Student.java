package DAY3;

public class Student {
	int rollno;
	String name;
	int m1;
	int m2;
	float avg;
	
	public void avg() {
		// TODO Auto-generated method stub
		avg=(float) ((m1+m2)/2.0);
	}
}
