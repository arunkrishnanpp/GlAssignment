package DAY3;

public class Student {
	public int rollno;
	public	String name;
	public	int m1;
	public	int m2;
	public float avg;
	
/*	
	public Student(){
		this.rollno=rollno;
		this.name=name;
		this.m1=m1;
		this.m2=m2;
		//avg();
	//	this.avg=((m1+m2)/2);
	}*/
	
	
	public void avg() {
		System.out.println("inside avg");
		// TODO Auto-generated method stub
		this.avg=(float) ((m1+m2)/2.0);
		//System.out.println(avg);
	}
}
