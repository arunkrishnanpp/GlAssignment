package DAY3;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="I am learning Java";
		int c=0,p=0;
	//	System.out.println(s1.indexOf(" ",0));
		while(p!=-1) {
			
			p=s1.indexOf(" ",p);
			//System.out.println(p);
			if(p==-1)
				break;
			c++;
			p++;
		}
	
	System.out.println("number of space="+c);
	}
	

}
