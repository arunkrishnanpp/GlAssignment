package DAY11;

public class hdfc extends Bank {
float get_roi() {
	return 6.7f;
}
	
}
