package DAY11;

public abstract class Bank {
abstract float get_roi();


void show() {
	System.out.println("Bank Details");
}
	
	
}
