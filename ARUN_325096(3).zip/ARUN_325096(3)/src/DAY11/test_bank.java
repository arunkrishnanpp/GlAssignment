package DAY11;

public class test_bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bank b;
		
		
		b=new icici();
		b.show();
		System.out.println("ICICI:"+b.get_roi());
		
		
		b=new hdfc();
		b.show();
		System.out.println("HDFC:"+b.get_roi());
	
	
	}
	
	

}
