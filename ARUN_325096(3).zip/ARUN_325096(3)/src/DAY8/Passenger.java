package DAY8;

public class Passenger {
	int sl_no;
	String name;
	String from;
	String to;
	double rate;
	int no_seat;
	double t;
	
	
	public void total() {
		this.t=rate*no_seat;
	}
	
	

}
