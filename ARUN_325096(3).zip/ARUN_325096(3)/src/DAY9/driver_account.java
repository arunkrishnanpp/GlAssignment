package DAY9;

public class driver_account {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
account acc=new account();


acc.setAccount_no(2000);
acc.setAccount_bal(50000);
System.out.println("Account number:"+acc.getAccount_no()+"\nAccount balance:"+acc.getAccount_bal());
	}

}