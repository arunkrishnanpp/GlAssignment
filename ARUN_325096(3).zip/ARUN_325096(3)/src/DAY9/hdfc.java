package DAY9;

public class hdfc extends Bank {

	
	public float ROI() {
		return 9.8f;
	}
	
	
}
