package DAY10;

public class result {
int cid;
String name;
int rid;
String from;
String to;
double unit_price;
int no;
double price;
}
