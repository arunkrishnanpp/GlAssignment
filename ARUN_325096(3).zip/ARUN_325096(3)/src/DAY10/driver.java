package DAY10;

import java.util.ArrayList;



public class driver {
	
	public static ArrayList<table1> list1;
	static ArrayList<table2> list2;
	static ArrayList<table3> list3;

	public static void main(String[] args) {
		
		
		
		
		
		excel_op op=new excel_op();
		calculation c=new calculation();

		op.read_excel_table1();
		
		
		
		for(table1 t:list1) {
			
			
			System.out.println(t.route_id);
		}
		// TODO Auto-generated method stub
		
		
		op.read_excel_table2();
		System.out.println(list1.get(0));

		for(table2 t:list2) {
			
			
			System.out.println(t.c_id);
		}
		
		op.read_excel_table3();

for(table3 t:list3) {
			
			
			System.out.println(t.no_of_ticket);
		}
		
		int count=2;
	for(int i=0;i<=1;i++) {
		result re=new result();
		table3 t3 =list3.get(i);
		c.serch2(re,t3.cid);
		
		System.out.println(re.cid);
		
		c.serch1(re,t3.rid);
		re.no=t3.no_of_ticket;
		re.price=re.unit_price*re.no;
		System.out.println(re.price);
		op.excel_write(re,count);
		count++;
		
		
		
		
	}
	
	
	
	
	
	}
	
	
	
	
	
	
	
	
	
	
	

}
