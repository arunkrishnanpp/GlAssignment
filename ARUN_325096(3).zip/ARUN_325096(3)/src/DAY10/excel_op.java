package DAY10;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_op extends driver{

	public void read_excel_table1() {
		// TODO Auto-generated method stub
		
		list1=new ArrayList<table1>();
		
		
		for(int i=2;i<=3;i++) {
			table1 t1=new table1();
			
			
			try {
				File f=new File("C:\\Gltraining\\Book4.xlsx");
				FileInputStream fi=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fi);
				XSSFSheet sh=wb.getSheet("sheet1");
				XSSFRow r=sh.getRow(i);
				XSSFCell c=r.getCell(0);
				t1.route_id=(int) c.getNumericCellValue();
				XSSFCell c1=r.getCell(1);
				t1.from=c1.getStringCellValue();
				XSSFCell c2=r.getCell(2);
				t1.to=c2.getStringCellValue();
				XSSFCell c3=r.getCell(3);
				t1.unit_price=c3.getNumericCellValue();
				
				
				list1.add(t1);
				
				
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			
		}
		
		
		
	}

	public void read_excel_table2() {
		// TODO Auto-generated method stub
		
list2=new ArrayList<table2>();
		
		
		for(int i=2;i<=3;i++) {
			table2 t2=new table2();
			
			
			try {
				File f=new File("C:\\Gltraining\\Book4.xlsx");
				FileInputStream fi=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fi);
				XSSFSheet sh=wb.getSheet("sheet2");
				XSSFRow r=sh.getRow(i);
				XSSFCell c=r.getCell(0);
				t2.c_id=(int) c.getNumericCellValue();
				XSSFCell c1=r.getCell(1);
				t2.name=c1.getStringCellValue();
				
				
				list2.add(t2);
				
				
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			
		}
		

		
		
	}
	
	
	
	
	public void read_excel_table3() {
		// TODO Auto-generated method stub
		
list3=new ArrayList<table3>();
		
		
		for(int i=2;i<=3;i++) {
			table3 t3=new table3();
			
			
			try {
				File f=new File("C:\\Gltraining\\Book4.xlsx");
				FileInputStream fi=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fi);
				XSSFSheet sh=wb.getSheet("sheet3");
				XSSFRow r=sh.getRow(i);
				XSSFCell c=r.getCell(0);
				t3.cid=(int) c.getNumericCellValue();
				XSSFCell c1=r.getCell(1);
				t3.rid=(int) c1.getNumericCellValue();
				XSSFCell c2=r.getCell(2);
				t3.no_of_ticket=(int) c2.getNumericCellValue();
				
				
				list3.add(t3);
				
				
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			
		}
		

		
		
	}

	public void excel_write(result re, int count) {
		// TODO Auto-generated method stub
		
		
		try {
			File  f=new File("C:\\Gltraining\\Book4.xlsx");
			FileInputStream  fi=new FileInputStream(f);
			XSSFWorkbook wb1=new XSSFWorkbook(fi);
			XSSFSheet sh1=wb1.getSheet("sheet4");
			
			XSSFRow r=sh1.createRow(count);
			XSSFCell c1=r.createCell(0);
			c1.setCellValue(re.cid);
			
			XSSFCell c2=r.createCell(1);
			c2.setCellValue(re.name);
			
			
			XSSFCell c3=r.createCell(2);
			c3.setCellValue(re.from);
			
			XSSFCell c4=r.createCell(3);
			c4.setCellValue(re.to);
			
			XSSFCell c5=r.createCell(4);
			c5.setCellValue(re.unit_price);
			
			
			XSSFCell c6=r.createCell(5);
			c6.setCellValue(re.no);
			XSSFCell c7=r.createCell(6);
			c7.setCellValue(re.price);
			FileOutputStream out=new FileOutputStream(f);
			wb1.write(out);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	
	
	
}
