package DAY10;

public class table1 {
int route_id;
String from;
String to;
double unit_price;
}
