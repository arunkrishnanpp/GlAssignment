package DAY10;

public class table3 {
int cid;
int rid;
int no_of_ticket;
}
