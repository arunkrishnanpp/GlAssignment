package DAY10;

public class calculation extends driver {

	public void serch2(result re, int cid) {
		// TODO Auto-generated method stub
		
		for(table2 out:list2) {
			if(cid==out.c_id) {
				re.cid=cid;
				re.name=out.name;
			}
		}
		
		
		
		
		
	}

	public void serch1(result re, int rid) {
		
		
		// TODO Auto-generated method stub
		
		for(table1 out:list1) {
			if(rid==out.route_id) {
				//re.rid=out.route_id;
				re.from=out.from;
				re.to=out.to;
				re.unit_price=out.unit_price;
				
				
				
			}
		}
		
		
	}

	
	
	
	
	
}
