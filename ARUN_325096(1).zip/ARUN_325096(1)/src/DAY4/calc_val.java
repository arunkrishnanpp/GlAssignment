package DAY4;

public class calc_val {

	
	
	

	public static void main(String args[]) {
		
		
		
		calc c=new calc();
		c.add(1, 4);
		c.add(10, 4.3);
		c.add(1, 3);
		
		System.out.println(c.add(1.0f, 3.0f));
	}
}
