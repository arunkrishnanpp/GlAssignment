package DAY4;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int cmax=4;
		int dmax=1;
		//int xmax=1;
		for(int r=1;r<=3;r++) {
			
			
			
			for(int c=1;c<=cmax;c++) {
				System.out.print(" ");
				
			}
			for(int d=1;d<=dmax;d++) {
				System.out.print(1+" ");
			
			
				
				
			}
			
		

			
		
			
				
			
			for(int d=1;d<=dmax;d++) {
				System.out.print(1+" ");
			
			
				
				
			}
			for(int c=1;c<=cmax-1;c++) {
				System.out.print(" ");  
				
			}
		
			System.out.println();
		
		
			cmax-=2;
			dmax++;
		
		
		}
		
		
		}
		
		
		
		
		

		
		
		
	}


