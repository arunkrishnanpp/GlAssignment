package DAY5;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{int n=10,m=1,p;


		p=n/m;
		System.out.println(p);

		int []a= {1,2,3};
		System.out.println(a[3]);
		}
		
		
		catch(ArithmeticException e)
		{
			System.out.println("arithemetic");
		}
		
		catch(ArrayIndexOutOfBoundsException r)
		{
			System.out.println("array");
		}
		
		catch(Exception n) {
			System.out.println("exception");
		}
		
		System.out.println("out of block");
	}

}
