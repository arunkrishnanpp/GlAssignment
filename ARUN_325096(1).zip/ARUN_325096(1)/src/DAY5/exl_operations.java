package DAY5;

import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class exl_operations {

	
public student read_exel(int row) {
	
	
	
	student s=new student();
	try {
		File f1=new File("C:\\Gltraining\\data.xlsx");
		//File  f=new File("C:\\Gltraining\\Book1.x");
		
		FileInputStream fi=new FileInputStream(f1);
		XSSFWorkbook wb=new XSSFWorkbook(fi);
		XSSFSheet sh=wb.getSheet("sheet1");
		
		//for(int i=0;i<2;i++) 
		//XSSFRow r=sh.getRow(1);
		//XSSFCell c=r.getCell(0);
		//String s=c.getStringCellValue();
		//System.out.println(s);//
//		/XSSFRow r=sh.createRow(2);
		XSSFRow r=sh.getRow(row);
		XSSFCell c=r.getCell(0);
		System.out.println(c.getNumericCellValue());
		s.rollno=(int) c.getNumericCellValue();
		XSSFCell c1=r.getCell(1);
		s.name=c1.getStringCellValue();
		XSSFCell c2=r.getCell(2);
		System.out.println((int) c2.getNumericCellValue());
		
		s.m1=(int) c2.getNumericCellValue();
		XSSFCell c3=r.getCell(3);
		System.out.println((int) c3.getNumericCellValue());
		s.m2=(int) c3.getNumericCellValue();
		
		System.out.println(s.m2);

		
		


		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return s;
		}

	


	
	 
	
	
	


public void write_exel(int row,student s)
{try {
	File f1=new File("C:\\Gltraining\\data.xlsx");
	//File  f=new File("C:\\Gltraining\\Book1.x");
	
	FileInputStream fi=new FileInputStream(f1);
	XSSFWorkbook wb=new XSSFWorkbook(fi);
	XSSFSheet sh=wb.getSheet("sheet1");
	XSSFRow r=sh.getRow(row);
	XSSFCell c=r.createCell(4);
	System.out.println(s.m1);
	System.out.println(s.m2);
	
	s.avg();
	
	c.setCellValue((double)s.avg);
	FileOutputStream fos=new FileOutputStream(f1);
	wb.write(fos);
}

catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

	
	
}
}
