package DAY5;

//import java.util.ArrayList;


public class mainn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//exl_operations x=new exl_operations();
		//Student v=x.read_exel(1);
		//Student v1=x.read_exel(2);
		
		exl_operations x=new exl_operations();
		student v=new student();
		
			for(int i=1;i<=2;i++) {
			v=x.read_exel(i);
			
			x.write_exel(i, v);
			}
			
			
			
		}
		
		
	
		//System.out.println(v.m1);
		//System.out.println(v.avg);
	
		//x.write_exel(2, v1);
		
		
		
		
		
		
	}


