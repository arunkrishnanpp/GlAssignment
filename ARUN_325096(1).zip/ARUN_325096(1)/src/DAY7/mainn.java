package DAY7;

import java.util.ArrayList;

public class mainn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//exl_operations x=new exl_operations();
		//Student v=x.read_exel(1);
		//Student v1=x.read_exel(2);
		
		exl_operations x=new exl_operations();
		ArrayList<Student> st=new ArrayList<Student>();
			
			st=x.read_exel();
			x.write_exel(st);
			
			
			for(Student f:st) {
				System.out.println(f.name);
			}
			
		}
		//System.out.println(v.m1);
		//System.out.println(v.avg);
	
		//x.write_exel(2, v1);
		
		
		
		
		
		
	}


