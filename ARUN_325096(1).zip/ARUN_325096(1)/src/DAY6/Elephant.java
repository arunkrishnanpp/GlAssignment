package DAY6;

public class Elephant extends Animal{
		int lenghtoftrunk;
		int lenghtoftusks;
		public void iam() {
			System.out.println("******************\ni am elephant");
		}
		public void swim() {
			System.out.println("Elephant swims");
		}
		

		public void spraying() {
			System.out.println("Elephant sprays using trunks");
		}
		
		
	


		public Elephant(int lot, int lotusk, int age, String color, String food, String gender, String name, int nol) {
			// TODO Auto-generated constructor stub
			
			this.lenghtoftrunk=lot;
			this.lenghtoftusks=lotusk;
			
			this.age=age;
			this.color=color;
			this.food=food;
			this.gender=gender;
			this.name=name;
			this.no_of_leg=nol;
			
			iam();
			display();
			display_elephant();
			
			eats();
			 runs();
			
			swim();
			bath();
		}


		public void display_elephant() {
			
			
			System.out.println("\n Length of trunk : "+ this.lenghtoftrunk + "\n Length of tusks: " + this.lenghtoftusks);
		}
}
