package DAY6;



	public class pgm4 {

		public static void main(String[] args) {
			// TODO Auto-generated method stub

			 new Elephant(7,6,28,"Black","Tree leaf","female","ABC",4);
			new Tiger(7,9,24,"orange","Non veg","male","TIGER");
			new Tiger(8,5,43,"white","veg","female","white TIGER");
			
			
		
			
			
			
			
			
			
			


}
}
