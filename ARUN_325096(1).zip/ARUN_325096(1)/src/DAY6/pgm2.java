package DAY6;

import java.util.ArrayList;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> str=new ArrayList<String>();
str.add("hello");
str.add("hiiiii");
str.add("how are you");
System.out.println("befor Insertion::"+str);
//System.out.println(str.get(2));
str.add(1, "hi hi");
System.out.println("After Insertion::"+str);


str.remove(0);
System.out.println("After deletion::"+str);

str.remove("hiiiii");
/*for(String s: str)
	System.out.println(s);

*/
	}

}
