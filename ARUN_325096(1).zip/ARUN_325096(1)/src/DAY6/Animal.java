package DAY6;

public class Animal {
	
	int no_of_leg;
	String color;
	String food;
	String name;
	String gender;
	int age;
	
	
	public void walks() {
		System.out.println("the animal walks\n");
	}
	
	public void eats() {
		System.out.println("the animal eats\n");
	}
	
	public void runs() {
		System.out.println("the animal runs\n");
	}
	public void bath() {
		
		System.out.println("animal is bathing");
	}
	
	
	public void display() {
		System.out.println("\n Name: "+this.name+" \nNo of legs: " +this.no_of_leg+ "\n Skin color: "+ this.color + "\n Food: " + this.food  
							+ "\n Gender: " + this.gender + "\n Age: " + this.age );
	}
	
}
