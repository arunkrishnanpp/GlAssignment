import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions()
public class testrunner extends AbstractTestNGCucumberTests {

	
	
	
	
}


