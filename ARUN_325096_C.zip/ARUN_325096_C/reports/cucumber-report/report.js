$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("a.feature");
formatter.feature({
  "line": 1,
  "name": "AUT  Login",
  "description": "",
  "id": "aut--login",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 9,
  "name": "Login with invalid data",
  "description": "",
  "id": "aut--login;login-with-invalid-data",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 8,
      "name": "@Round2"
    }
  ]
});
formatter.step({
  "line": 10,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "User invaluid login data and click ok button",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "error mesgae displyed",
  "keyword": "Then "
});
formatter.match({
  "location": "test1.login_page_is_displayed()"
});
formatter.result({
  "duration": 8228705700,
  "status": "passed"
});
formatter.match({
  "location": "test2.user_invaluid_login_data_and_click_ok_button()"
});
formatter.result({
  "duration": 764822100,
  "status": "passed"
});
formatter.match({
  "location": "test2.error_mesgae_displyed()"
});
formatter.result({
  "duration": 35438901,
  "error_message": "java.lang.AssertionError: The following asserts failed:\n\texpected [Login was unsuccessful. Please correct the errors annd try again.] but found [Login was unsuccessful. Please correct the errors and try again.]\r\n\tat org.testng.asserts.SoftAssert.assertAll(SoftAssert.java:43)\r\n\tat STEP_DEF.test2.error_mesgae_displyed(test2.java:41)\r\n\tat ✽.Then error mesgae displyed(a.feature:12)\r\n",
  "status": "failed"
});
});