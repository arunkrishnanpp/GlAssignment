package KEYWORD_WITH_TC_SEL;

public class key {
	
	
	public String TC_ID;
	public String step_no;
	public String KeyWord;
	public String Xpath;
	public String Test_data;
	}



