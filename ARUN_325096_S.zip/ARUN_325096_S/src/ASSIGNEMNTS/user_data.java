package ASSIGNEMNTS;

public class user_data {
String gender,f_name,l_name,email,pass,c_pass,account;
}
