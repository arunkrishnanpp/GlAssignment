package SDAY5;

import org.testng.annotations.Test;

public class NewTest1 {
  @Test
  public void t1() {
	  System.out.println("in Test 1");
  }
  @Test
  public void t2() {
	  System.out.println("IN TEST 2");
  }
  

  public void t3() {
	  System.out.println("IN TEST 3");
  }
}
