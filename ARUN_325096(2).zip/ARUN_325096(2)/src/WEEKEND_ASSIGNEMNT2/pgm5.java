package WEEKEND_ASSIGNEMNT2;

import java.util.ArrayList;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String line="i have learnt loops, opps concept, inheritance, exception handling, arraylist string handling";
		String line1=line.replace(",","");
		ArrayList<String> li=new ArrayList<String>(); 
		
		li=get_each_word(line1);
		System.out.println("WORD WITH MORE THAN 3  VOWELS");
		for(String d:count_vowel(li)) {
			System.out.println(d);
		}
		
	}

	private static ArrayList<String> count_vowel(ArrayList<String> li) {
		ArrayList<String> li1=new ArrayList<String>(); 
		// TODO Auto-generated method stub
		for(String s:li) {
							int count =0;
							
							for(int i=0;i<s.length();i++) {
								
											if(s.charAt(i)=='a'||s.charAt(i)=='e'||s.charAt(i)=='i'||s.charAt(i)=='o'||s.charAt(i)=='u') {
												count++;
												
												
											}
								
															}
							if(count>=3) {
								li1.add(s);
								
							}
							
				
			
			
			
						}
		
		/*for(String s:li1)
			System.out.println(s);
		*/
		
		return li1;
		
	}

	private static ArrayList<String> get_each_word(String line) {
		// TODO Auto-generated method stub
		ArrayList<String> list=new ArrayList<String>();
		
		int c=0,p=0;
		
		while(p!=-1) {
			p=line.indexOf(" ",p);
			
			if(p==-1) {
				//System.out.println(line.substring(c, line.length()));
				list.add(line.substring(c, line.length()));
				break;
			}
			
			else {
				//System.out.println(line.substring(c,p));
				list.add(line.substring(c,p));
			}
			
			c=p+1;
			p++;
			
			
			
		}
		
		/*
		for(String s:list) {
			System.out.println(s);
		}
		System.out.println("*******************");*/
		return list;
		
	}

}
