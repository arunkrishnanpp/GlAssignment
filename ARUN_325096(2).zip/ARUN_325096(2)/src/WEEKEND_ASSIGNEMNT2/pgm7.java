package WEEKEND_ASSIGNEMNT2;

import java.util.ArrayList;

public class pgm7 {

	static ArrayList<Product>list;
	public static void main(String args[]) {
		
		exel_operation op=new exel_operation();
		//ArrayList<Product>list1=new ArrayList<Product>();
		
		/*for(Product p:op.read_excel()) {
			System.out.println(p.poduct_name);
			System.out.println(p.product_id);
			System.out.println(p.unit_price);
			System.out.println(p.unit_purchase);
		}*/
		
	op.read_excel();
		
		
		for(Product p:list) {
			p.Price();
			p.Product_Grade();
		}
		
		
		/*for(Product p:list1) {
			System.out.println(p.poduct_name+p.product_grade);
		}*/
		
	op.write_excel();
	}
}
