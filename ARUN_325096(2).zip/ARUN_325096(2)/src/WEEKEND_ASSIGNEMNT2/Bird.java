package WEEKEND_ASSIGNEMNT2;

public class Bird {
	
	int no_of_leg;
	String color;
	String food;
	String name;
	String gender;
	int age;
	String species;
	String region;
	String climate;
	
	
	public void walks() {
		System.out.println("the Bird walks\n");
	}
	
	public void eats() {
		System.out.println("the Bird eats\n");
	}
	
	public void fly() {
		System.out.println("the Birds runs\n");
	}
	public void bath() {
		
		System.out.println("birds bath");
	}
	
	
	public void display() {
		System.out.println("\n Name: "+this.name+" \nNo of legs: " +this.no_of_leg+ "\n Skin color: "+ this.color + "\n Food: " + this.food  
							+ "\n Gender: " + this.gender + "\n Age: " + this.age+"\nBird Species is "+this.species+"\n found in"+this.region +"\n In climate:"+this.climate);
	}
	
}
