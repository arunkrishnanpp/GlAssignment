package WEEKEND_ASSIGNEMNT2;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		new Parrots(2,"green","fruits","aaa","male",23,"Parrot","every where","warm","parakeet","malayalam");
		 
		new Parrots(2,"green and red","buds","bb","male",2,"Parrot","every where","warm","cockato","malayalam");
		 
		new Parrots(2,"green ","fruits and seeds","c","female",3,"Parrot","every where","warm","love bird","malayalam");
		 
		
		new Owls(2,"brows","insects","ddd","male",2,"baen owl","except polar region","warm");
		new Owls(2,"hash","squirrels","eee","female",3,"snowy owl","every where","cool");
		 
	}

}
