package WEEKEND_ASSIGNEMNT2;

public class Parrots extends Bird{
		String knows_language;
		String sub_type;
		
		public void iam() {
			System.out.println("******************\ni am a Parrot");
		}
		public void singSong() {
			System.out.println("parrot is singing");
		}
		public Parrots(
				int no_of_leg,
				String color,
				String food,
				String name,
				String gender,
				int age,
				String species,
				String region,
				String climate,
				String subtype,
				String language
				) {
			
			this.no_of_leg=no_of_leg;
			this.color=color;
			 this.food=food;
			this.name=name;
			this.gender=gender;
			this.age=age;
			
			 this.species=species;
		 this.region=region;
			 this.climate=climate;
			 this.sub_type=subtype;
			 this.knows_language=language;
			
			
			 display_parrots();
			 
			 
			
			
			
			
		}	

		
		
		
	


		


		public void display_parrots() {
			 iam();
			singSong();
			display();
			System.out.println("\n Language knows : "+ this.knows_language + "\n Subtype: " + this.sub_type);
		}
}
