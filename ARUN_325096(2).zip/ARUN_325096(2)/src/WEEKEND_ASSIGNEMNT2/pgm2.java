package WEEKEND_ASSIGNEMNT2;
import java.lang.Math; 

public class pgm2 {
public static  boolean IsAmstrong(int x) {
		
		boolean f; 
		int n=x;
		int v=x;
		int rev=0;
		int d=0;
	
		
		
		
		
		 
	        int order = 0; 
	        while (v > 0) 
	        { 
	            order++; 
	            v = v/10; 
	        }// System.out.println(order);
	      
	     
		while(n>0) {
			d=n%10;
			rev=(int) (rev+Math.pow(d,order));
			n/=10;
			
		}
		
		if(rev==x) {
			//System.out.println("AMS");
			f=true;
			
		}
		else {
			//System.out.println("NOT AMS");
		f=false;}
		return f;
	
		
		
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//IsAmstrong(152);
		int count=0;
		int x=100;
		int[] array=new int[5];
		while(count<	5) {
			if(IsAmstrong(x))
			{	System.out.println(x);
				array[count]=x;
				count++;
			}
			x++;
		}
			
			
			
			
			
			
		
	}
}