package WEEKEND_ASSIGNEMNT;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] a1=new int[20];
		int [] a2=new int[20];
		int index1=0;
		int index2=0;
		for(int i=10;i<=30;i++) {
			if(i%3==0) {
				a1[index1]=i;
				index1++;
			}
			if(i%5==0) {
				a2[index2]=i;
				index2++;
			}
				
		}
		
		 System.out.printf("%1s %15s %16s", "First Array", "Second Array", "Sum");
		System.out.println();
		for(int i=0;i<index1;i++) {
			for(int j=0;j<index2;j++) {
				if(a1[i]+a2[j]>30&&a1[i]+a2[j]<40) {
				int x=	a1[i]+a2[j];
				
					//System.out.println(a1[i]+"+"+a2[j]+"="+x);
					
					System.out.format("%1s %15s %25s",a1[i],a2[j],x);
					System.out.println();
				}
				
				
			}
			
			
			
		}
		
		
	
		
		
		
	}

}
