package PKG_1;

import org.testng.annotations.Test;

public class NewTest1 {
  @Test
  public void f() {
	  System.out.println("maven 3 packge 1 NewTest1");
  }
}
